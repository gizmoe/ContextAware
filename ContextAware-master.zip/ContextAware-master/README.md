#ContextAware

Try to work on it in branches, and merge whenever stuff works
